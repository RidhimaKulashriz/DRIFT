# DRIFT Deployment Audit

## Release configuration matrix

| Stack area | Configuration | Required to boot | Production requirement | Safe fallback when absent |
|---|---|---:|---:|---|
| Frontend | `VITE_APP_TITLE`, `VITE_APP_LOGO`, `VITE_APP_ID`, `VITE_OAUTH_PORTAL_URL` | Yes for branded/authenticated UI | Keep managed values; never commit secrets | Authentication and branding use managed project defaults |
| Frontend/maps | `MapView` through the Manus Google Maps proxy | No separate Google API key | Use the managed proxy; do not request or commit a Google key | Coordinates remain visible in mission/evidence records and the workbench shows a truthful provider-unavailable state |
| Backend/auth | `JWT_SECRET`, `OAUTH_SERVER_URL`, owner identity, built-in Forge URL/key | Yes | Keep managed secrets and rotate according to release policy | No safe anonymous access to protected operations; public simulator/read procedures remain intentionally limited |
| Database | `DATABASE_URL` | Yes for persistence | Enable SSL where supported and apply Drizzle migrations before release | Server refuses persistent mission/evidence operations rather than fabricating data |
| Storage | Built-in storage helpers and Forge credentials | Yes for evidence/report artifacts | Use managed object storage; store references and hashes, not file bytes in MySQL | Upload/report operations fail explicitly; existing metadata remains queryable |
| ML/CV | `ML_INFERENCE_URL`, optional `ML_INFERENCE_TOKEN` | No | Configure a calibrated, domain-specific CV service and validate its response schema | Deterministic fallback labels findings as advisory, applies server calibration, records provenance, and requires human review |
| AI decision support | Built-in Forge/LLM configuration | No for core operations | Review model output and retain structured narrative/audit state | Deterministic narrative fallback is used when the AI service is unavailable |
| Drone bridge | `DRIFT_INGEST_TOKEN`, optional `DRIFT_HARDWARE_ENDPOINT` | Token required only for live bridge calls | Use a long random token; connect PX4/ArduPilot through an operator-controlled companion computer and authenticated HTTPS bridge | Hardware status is offline/degraded and simulator mode remains available; DRIFT never controls flight |
| Media bridge | RTSP source handled by the approved companion bridge, then bounded still/clip uploads | No for simulator | Preserve stream/frame IDs, timestamps, camera IDs, checksums, and capture zones | No live media is fabricated; evidence remains unavailable until a trusted upload arrives |
| Runtime safety | PX4/ArduPilot geofence and lost-link failsafe | External flight-system responsibility | Configure and bench-test hold/RTL/land/operator-defined failsafe before live missions | DRIFT marks bridge degraded/offline and rejects stale telemetry; it does not send corrective commands |

## Verification status

Core managed variables for the current project are present, including database, OAuth, JWT, Forge, and the newly generated bridge token. `ML_INFERENCE_URL` and `DRIFT_HARDWARE_ENDPOINT` are intentionally optional for simulator/fallback mode. The browser map uses the managed Manus Google Maps proxy, so no user-supplied Google Maps key is required.

The latest local release gate passed TypeScript validation, 27 Vitest tests, the production build, authenticated real-image evidence upload, fallback inference persistence, correlation persistence, and application-generated report creation. Remaining field gates are organisation-specific: deploy a calibrated production CV endpoint, bench-test the chosen PX4/ArduPilot hardware and camera bridge, and complete flight/airspace and engineering approvals.

## Deployment action

After reviewing the saved checkpoint in the Management UI, the project owner must click **Publish**. Publishing is intentionally user-triggered. If the project will serve multiple organisations, add organisation membership and tenant IDs to every operational table before onboarding independent customers; the current release is suitable for a single-operator deployment with role authorization and audit controls.

## Remaining external gates and release classification

The current checkpoint is **deployment-prepared, not field-certified**. The local application and release checks are green, but the following gates remain external: the latest expanded local source cannot be pushed through the current GitHub integration because all write endpoints return `Resource not accessible by integration`; the existing correct source PR #7 is already merged, but it does not contain this latest local checkpoint. The browser preview can be rendered and documented, but this session does not expose click-level panel navigation for individually selecting every filter and review surface. Live CV calibration, PX4/ArduPilot bench testing, camera/RTSP integration, airspace approval, and qualified engineering sign-off must occur in the target organisation’s environment.

Publishing is a user-triggered Management UI operation. It must be performed only after reviewing the checkpoint and accepting the documented external gates.
